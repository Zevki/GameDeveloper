using UnityEngine;


using UnityEngine.InputSystem;
using TMPro;

public class PlayerController : MonoBehaviour {
	

	public float speed;
	public TextMeshProUGUI countText;
	public TextMeshProUGUI position_Display;
	public TextMeshProUGUI veclocity_Display;
	public GameObject winTextObject;

    private float movementX;
    private float movementY;
	private Vector3 previousPosition;
	private LineRenderer lineRenderer;

	private Rigidbody rb;
	private int count;


	void Start ()
	{

		rb = GetComponent<Rigidbody>();
		count = 0;
		SetCountText();
        winTextObject.SetActive(false);
		lineRenderer = GetComponent<LineRenderer>();

	}

	void FixedUpdate ()
	{
		
		Vector3 movement = new Vector3 (movementX, 0.0f, movementY);

		rb.AddForce (movement * speed);

		position_Display.text = "Position: " + transform.position.ToString();

		Vector3 velocity = (transform.position - previousPosition) / Time.deltaTime;
		previousPosition = transform.position;
		veclocity_Display.text = "Velocity: " + velocity.magnitude.ToString("F2");

	}

	void OnTriggerEnter(Collider other) 
	{

		if (other.gameObject.CompareTag ("PickUp"))
		{
			other.gameObject.SetActive (false);
			count = count + 1;
			SetCountText ();
		}
	}

    void OnMove(InputValue value)
        {
        	Vector2 v = value.Get<Vector2>();

        	movementX = v.x;
        	movementY = v.y;
        }

    void SetCountText()
	{
		countText.text = "Count: " + count.ToString();

		if (count >= 12) 
		{
            winTextObject.SetActive(true);
		}
	}
}